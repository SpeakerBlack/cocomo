<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css"> <!-- CSS Boostrap -->
	<link href="http://hayageek.github.io/jQuery-Upload-File/uploadfile.min.css" rel="stylesheet"> <!-- CSS Upload file -->
	<link rel="stylesheet" type="text/css" href="../style/style.css"> <!-- CSS global -->
	<link rel="stylesheet" type="text/css" href="style.css"> <!-- CSS local -->
</head>
<body>