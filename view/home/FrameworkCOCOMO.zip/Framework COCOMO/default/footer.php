	<script src="http://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
	<script src="http://hayageek.github.io/jQuery-Upload-File/jquery.uploadfile.min.js"></script>	
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js" type="text/javascript"></script>
	<script src="../default/cocomo.js" type="text/javascript"></script>
	<script src="application.js" type="text/javascript"></script>
</body>
</html>